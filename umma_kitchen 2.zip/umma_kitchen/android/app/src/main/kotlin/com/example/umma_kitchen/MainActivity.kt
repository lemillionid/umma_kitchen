package com.example.umma_kitchen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
